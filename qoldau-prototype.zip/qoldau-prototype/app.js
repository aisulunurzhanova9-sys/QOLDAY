const translations = {
  kk: {
    brandSubtitle:"Қолжетімді байланыс", navHome:"Басты бет", navTranslator:"Аудармашы", navHelp:"Көмек", navReviews:"Пікірлер",
    eyebrow:"АҚТӨБЕ · ҚАЗАҚША / РУССКИЙ", heroTitle:"Сізге көмектесуге дайынбыз!", heroText:"Ымдау тілі аудармашысымен байланысыңыз немесе қажетті көмекті таңдаңыз.",
    callTranslator:"Онлайн аудармашыны шақыру", translatorStatus:"Аудармашының мәртебесі", free:"Аудармашы бос", busy:"Аудармашы бос емес", demoMode:"Демо режимі",
    quickActions:"Жылдам әрекеттер", videoCall:"Бейнеқоңырау", videoCallDesc:"Аудармашымен байланысу", needHelp:"Маған көмек керек", needHelpDesc:"Қажетті көмек түрін таңдаңыз",
    textChat:"Мәтіндік байланыс", textChatDesc:"Демо хабарлама үлгісі", reviews:"Пікірлер", reviewsDesc:"Баға беріп, пікір қалдыру", safetyTitle:"Маңызды ақпарат",
    safetyText:"Бұл демонстрациялық прототип. Шұғыл жағдайда тиісті жедел қызметке тікелей хабарласыңыз.", backHome:"Басты бетке қайту",
    translatorSection:"ОНЛАЙН ҚЫЗМЕТ", translatorTitle:"Ымдау тілі аудармашысы", translatorIntro:"Бос аудармашымен тікелей байланысу мүмкіндігін тексеріңіз.",
    connectionStatus:"Қосылу мәртебесі", statusPrototype:"Бұл мәртебе прототип ішінде ғана басқарылады.", connectButton:"Аудармашыға қосылу",
    toggleStatus:"Демо: мәртебені өзгерту", noTranslatorTitle:"Қазір бос аудармашы жоқ", noTranslatorText:"Өтініш нақты кезекке қойылған жоқ. Кейінірек қайталап көріңіз немесе мәтіндік баламаны таңдаңыз.",
    tryText:"Мәтіндік байланысқа өту", backTranslator:"Аудармашы бөліміне қайту", demoCall:"ДЕМО ҚОҢЫРАУ", callTitle:"Бейнеқоңырау",
    callIntro:"Бұл экран нақты аудио немесе видео жібермейді.", interpreterLabel:"Сурдоаудармашы", sampleVideo:"Демонстрациялық көрініс",
    camera:"Камера", microphone:"Микрофон", endCall:"Аяқтау", callEnded:"Демо қоңырау аяқталды. Нақты қоңырау жасалған жоқ.",
    cameraOn:"Камера күйі: қосулы (демо).", cameraOff:"Камера күйі: өшірулі (демо).", micOn:"Микрофон күйі: қосулы (демо).", micOff:"Микрофон күйі: өшірулі (демо).",
    helpSection:"ҚОЛДАУ", helpTitle:"Қандай көмек қажет?", helpIntro:"Өзіңізге сәйкес нұсқаны таңдаңыз.", helpInterpreter:"Аудармашы қажет",
    helpInterpreterDesc:"Ымдау тілі арқылы сөйлесу", helpMedical:"Медициналық көмек қажет", helpMedicalDesc:"Медициналық мекемеде көмек сұрау",
    helpInstitution:"Мекемеде көмек қажет", helpInstitutionDesc:"Қызметкермен байланысу", emergencyTitle:"Шұғыл жағдай",
    emergencyText:"QOLDAU прототипі жедел қызметке қоңырау шалмайды. Өмірге немесе денсаулыққа қауіп төнсе, тиісті жедел қызметке тікелей хабарласыңыз.",
    chatTitle:"Мәтіндік байланыс", chatIntro:"Хабарлама үлгісін теріп көруге болады. Ол серверге жіберілмейді.",
    chatWelcome:"Сәлеметсіз бе! Бұл QOLDAU демо чаты.", messageLabel:"Хабарлама", messagePlaceholder:"Хабарламаңызды жазыңыз...", sendMessage:"Демо хабарлама қосу",
    messageAdded:"Хабарлама тек осы демонстрацияға қосылды. Серверге жіберілген жоқ.", feedbackSection:"КЕРІ БАЙЛАНЫС", reviewsTitle:"Пікірлер мен бағалау",
    reviewsIntro:"Пікірлер осы браузердегі демонстрацияға ғана қосылады.", ratingLabel:"Қызметті бағалаңыз", reviewTextLabel:"Пікіріңіз",
    reviewPlaceholder:"Қызмет туралы пікіріңізді жазыңыз...", submitReview:"Пікірді қосу", userReviews:"Пайдаланушылар пікірі",
    emptyReviews:"Әзірге пікір жоқ.", reviewAdded:"Пікір прототипке қосылды. Серверге сақталған жоқ.", reviewRequired:"Алдымен пікіріңізді жазыңыз.",
    helpSelected:"Таңдалған көмек түрі: ", helpDemo:"Бұл демонстрациялық таңдау ғана. Нақты қызметке өтініш жіберілген жоқ.", footerText:"Ақтөбе · Қолжетімді байланыс",
    footerDemo:"Демонстрациялық прототип · Нақты қызметтер қосылмаған", callRequested:"Демо бейнеқоңырау экраны ашылды. Нақты байланыс орнатылған жоқ."
  },
  ru: {
    brandSubtitle:"Доступная связь", navHome:"Главная", navTranslator:"Переводчик", navHelp:"Помощь", navReviews:"Отзывы",
    eyebrow:"АКТОБЕ · ҚАЗАҚША / РУССКИЙ", heroTitle:"Мы готовы помочь!", heroText:"Свяжитесь с переводчиком жестового языка или выберите нужную помощь.",
    callTranslator:"Вызвать онлайн-переводчика", translatorStatus:"Статус переводчика", free:"Переводчик свободен", busy:"Переводчик занят", demoMode:"Демо-режим",
    quickActions:"Быстрые действия", videoCall:"Видеозвонок", videoCallDesc:"Связаться с переводчиком", needHelp:"Мне нужна помощь", needHelpDesc:"Выберите тип помощи",
    textChat:"Текстовая связь", textChatDesc:"Демонстрационный чат", reviews:"Отзывы", reviewsDesc:"Оцените услугу и оставьте отзыв", safetyTitle:"Важная информация",
    safetyText:"Это демонстрационный прототип. В экстренной ситуации обратитесь напрямую в соответствующую экстренную службу.", backHome:"Вернуться на главную",
    translatorSection:"ОНЛАЙН-СЕРВИС", translatorTitle:"Переводчик жестового языка", translatorIntro:"Проверьте возможность прямого подключения к свободному переводчику.",
    connectionStatus:"Статус подключения", statusPrototype:"Статус можно менять только внутри прототипа.", connectButton:"Подключиться к переводчику",
    toggleStatus:"Демо: изменить статус", noTranslatorTitle:"Сейчас нет свободного переводчика", noTranslatorText:"Заявка не поставлена в реальную очередь. Попробуйте позже или выберите текстовую альтернативу.",
    tryText:"Перейти к текстовой связи", backTranslator:"Вернуться к переводчику", demoCall:"ДЕМО-ЗВОНОК", callTitle:"Видеозвонок",
    callIntro:"Этот экран не передаёт настоящее аудио или видео.", interpreterLabel:"Переводчик жестового языка", sampleVideo:"Демонстрационный экран",
    camera:"Камера", microphone:"Микрофон", endCall:"Завершить", callEnded:"Демонстрационный звонок завершён. Реальный звонок не выполнялся.",
    cameraOn:"Камера: включена (демо).", cameraOff:"Камера: выключена (демо).", micOn:"Микрофон: включён (демо).", micOff:"Микрофон: выключен (демо).",
    helpSection:"ПОДДЕРЖКА", helpTitle:"Какая помощь вам нужна?", helpIntro:"Выберите подходящий вариант.", helpInterpreter:"Нужен переводчик",
    helpInterpreterDesc:"Общение на жестовом языке", helpMedical:"Нужна медицинская помощь", helpMedicalDesc:"Попросить помощь в медицинском учреждении",
    helpInstitution:"Нужна помощь в учреждении", helpInstitutionDesc:"Связаться с сотрудником", emergencyTitle:"Экстренная ситуация",
    emergencyText:"Прототип QOLDAU не звонит в экстренные службы. При угрозе жизни или здоровью свяжитесь напрямую с соответствующей экстренной службой.",
    chatTitle:"Текстовая связь", chatIntro:"Можно набрать пример сообщения. Оно не отправляется на сервер.",
    chatWelcome:"Здравствуйте! Это демо-чат QOLDAU.", messageLabel:"Сообщение", messagePlaceholder:"Введите сообщение...", sendMessage:"Добавить демо-сообщение",
    messageAdded:"Сообщение добавлено только в демонстрацию. На сервер оно не отправлено.", feedbackSection:"ОБРАТНАЯ СВЯЗЬ", reviewsTitle:"Отзывы и оценки",
    reviewsIntro:"Отзывы добавляются только в демонстрацию этого браузера.", ratingLabel:"Оцените услугу", reviewTextLabel:"Ваш отзыв",
    reviewPlaceholder:"Напишите отзыв об услуге...", submitReview:"Добавить отзыв", userReviews:"Отзывы пользователей",
    emptyReviews:"Пока отзывов нет.", reviewAdded:"Отзыв добавлен в прототип. На сервер он не сохранён.", reviewRequired:"Сначала напишите отзыв.",
    helpSelected:"Выбран тип помощи: ", helpDemo:"Это только демонстрационный выбор. Реальная заявка не отправлена.", footerText:"Актобе · Доступная связь",
    footerDemo:"Демонстрационный прототип · Реальные сервисы не подключены", callRequested:"Открыт демо-экран видеозвонка. Реальное соединение не установлено."
  }
};

let language = "kk";
let availability = "free";
let selectedRating = 5;
const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
const t = key => translations[language][key] || translations.kk[key] || key;

function setLanguage(next) {
  language = next;
  document.documentElement.lang = next;
  $$("[data-i18n]").forEach(el => { el.textContent = t(el.dataset.i18n); });
  $$("[data-i18n-placeholder]").forEach(el => { el.placeholder = t(el.dataset.i18nPlaceholder); });
  updateAvailabilityUI();
  renderReviews();
  $("#language").value = next;
}
function navigate(page) {
  $$(".page").forEach(el => el.classList.toggle("active", el.id === `page-${page}`));
  $$(".nav-link").forEach(el => el.classList.toggle("active", el.dataset.page === page));
  $("#main-nav").classList.remove("open");
  $("#menu-toggle").setAttribute("aria-expanded", "false");
  window.scrollTo({top:0, behavior:"smooth"});
}
function updateAvailabilityUI() {
  const free = availability === "free";
  $("#home-status-dot").classList.toggle("busy", !free);
  $("#home-status-text").textContent = t(free ? "free" : "busy");
  $("#translator-status").classList.toggle("busy", !free);
  $("#translator-status").innerHTML = `● <span>${t(free ? "free" : "busy")}</span>`;
  $("#translator-description").textContent = t("statusPrototype");
  $("#connect-button").textContent = t("connectButton");
  $("#unavailable-notice").classList.toggle("hidden", free);
}
$$("[data-page]").forEach(el => el.addEventListener("click", () => navigate(el.dataset.page)));
$$("[data-go]").forEach(el => el.addEventListener("click", () => navigate(el.dataset.go)));
$("#language").addEventListener("change", e => setLanguage(e.target.value));
$("#menu-toggle").addEventListener("click", () => {
  const open = $("#main-nav").classList.toggle("open");
  $("#menu-toggle").setAttribute("aria-expanded", String(open));
});
$("#toggle-availability").addEventListener("click", () => {
  availability = availability === "free" ? "busy" : "free";
  updateAvailabilityUI();
});
$("#connect-button").addEventListener("click", () => {
  if (availability !== "free") {
    $("#unavailable-notice").classList.remove("hidden");
    return;
  }
  $("#call-feedback").textContent = t("callRequested");
  navigate("call");
});
$$("[data-help]").forEach(button => button.addEventListener("click", () => {
  const labels = {
    interpreter: language === "kk" ? "Аудармашы қажет" : "Нужен переводчик",
    medical: language === "kk" ? "Медициналық көмек қажет" : "Нужна медицинская помощь",
    institution: language === "kk" ? "Мекемеде көмек қажет" : "Нужна помощь в учреждении"
  };
  $("#help-feedback").textContent = t("helpSelected") + labels[button.dataset.help] + ". " + t("helpDemo");
  if (button.dataset.help === "interpreter") navigate("translator");
}));
let cameraEnabled = true, micEnabled = true;
$("#camera-toggle").addEventListener("click", () => {
  cameraEnabled = !cameraEnabled;
  $("#camera-toggle").classList.toggle("off", !cameraEnabled);
  $("#call-feedback").textContent = t(cameraEnabled ? "cameraOn" : "cameraOff");
});
$("#mic-toggle").addEventListener("click", () => {
  micEnabled = !micEnabled;
  $("#mic-toggle").classList.toggle("off", !micEnabled);
  $("#call-feedback").textContent = t(micEnabled ? "micOn" : "micOff");
});
$("#end-call").addEventListener("click", () => {
  $("#call-feedback").textContent = t("callEnded");
  navigate("translator");
});
$("#chat-form").addEventListener("submit", e => {
  e.preventDefault();
  const input = $("#chat-input");
  const value = input.value.trim();
  if (!value) return;
  const msg = document.createElement("div");
  msg.className = "chat-user-message";
  msg.textContent = value;
  $("#chat-messages").appendChild(msg);
  input.value = "";
  $("#chat-feedback").textContent = t("messageAdded");
});
$$("[data-rating]").forEach(button => button.addEventListener("click", () => {
  selectedRating = Number(button.dataset.rating);
  updateStars();
}));
function updateStars() {
  $$(".star").forEach(button => button.classList.toggle("selected", Number(button.dataset.rating) <= selectedRating));
}
const sampleReviews = [
  {rating:5, textKK:"Қызмет өте ыңғайлы. Рақмет!", textRU:"Очень удобный сервис. Спасибо!", author:"QOLDAU демо"},
  {rating:4, textKK:"Интерфейс түсінікті және қарапайым.", textRU:"Интерфейс понятный и простой.", author:"QOLDAU демо"}
];
let userReviews = [];
function renderReviews() {
  const list = $("#review-list");
  list.replaceChildren();
  const items = [...userReviews, ...sampleReviews];
  $("#review-count").textContent = String(items.length);
  if (!items.length) {
    const empty = document.createElement("p"); empty.textContent = t("emptyReviews"); list.appendChild(empty); return;
  }
  items.forEach(item => {
    const card = document.createElement("article"); card.className = "review-card";
    const meta = document.createElement("div"); meta.className = "review-meta";
    const stars = document.createElement("span"); stars.className = "review-stars"; stars.textContent = "★".repeat(item.rating) + "☆".repeat(5-item.rating);
    const author = document.createElement("span"); author.className = "review-author"; author.textContent = item.author;
    const text = document.createElement("p"); text.textContent = language === "kk" ? (item.textKK || item.text) : (item.textRU || item.text);
    meta.append(stars, author); card.append(meta, text); list.appendChild(card);
  });
}
$("#review-form").addEventListener("submit", e => {
  e.preventDefault();
  const value = $("#review-text").value.trim();
  if (!value) { $("#review-feedback").textContent = t("reviewRequired"); return; }
  userReviews.unshift({rating:selectedRating, text:value, author:language === "kk" ? "Пайдаланушы · демо" : "Пользователь · демо"});
  $("#review-text").value = "";
  $("#review-feedback").textContent = t("reviewAdded");
  renderReviews();
});
setLanguage("kk");
updateStars();
renderReviews();
